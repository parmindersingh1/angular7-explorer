<?php

/* AdminBundle::Listings/list.html.twig */
class __TwigTemplate_bc58bcee642070fa1644e8f954c83223effe53c8ff5b6dd18c77f40826d9a8b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AdminBundle::base.html.twig", "AdminBundle::Listings/list.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'page_title' => array($this, 'block_page_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AdminBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a26811431d6b1893801f4ffa9e36c69b7f55cd2a79fce1914915ac10f0542f20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a26811431d6b1893801f4ffa9e36c69b7f55cd2a79fce1914915ac10f0542f20->enter($__internal_a26811431d6b1893801f4ffa9e36c69b7f55cd2a79fce1914915ac10f0542f20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::Listings/list.html.twig"));

        $__internal_465fe8a9bfe8584a8bf162493fbaa54af162d08328a082171da55c575426cd4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_465fe8a9bfe8584a8bf162493fbaa54af162d08328a082171da55c575426cd4e->enter($__internal_465fe8a9bfe8584a8bf162493fbaa54af162d08328a082171da55c575426cd4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::Listings/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a26811431d6b1893801f4ffa9e36c69b7f55cd2a79fce1914915ac10f0542f20->leave($__internal_a26811431d6b1893801f4ffa9e36c69b7f55cd2a79fce1914915ac10f0542f20_prof);

        
        $__internal_465fe8a9bfe8584a8bf162493fbaa54af162d08328a082171da55c575426cd4e->leave($__internal_465fe8a9bfe8584a8bf162493fbaa54af162d08328a082171da55c575426cd4e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f3cd90d16e00820c1cc43eadac60e60fb9f5cb92d093e97d7f2fadfd2c763434 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f3cd90d16e00820c1cc43eadac60e60fb9f5cb92d093e97d7f2fadfd2c763434->enter($__internal_f3cd90d16e00820c1cc43eadac60e60fb9f5cb92d093e97d7f2fadfd2c763434_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0ba83d045dd8387c9b00858e3b44fe8d5fa6223ed2dff97165211bd3eae8ff60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ba83d045dd8387c9b00858e3b44fe8d5fa6223ed2dff97165211bd3eae8ff60->enter($__internal_0ba83d045dd8387c9b00858e3b44fe8d5fa6223ed2dff97165211bd3eae8ff60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Listings"), "html", null, true);
        
        $__internal_0ba83d045dd8387c9b00858e3b44fe8d5fa6223ed2dff97165211bd3eae8ff60->leave($__internal_0ba83d045dd8387c9b00858e3b44fe8d5fa6223ed2dff97165211bd3eae8ff60_prof);

        
        $__internal_f3cd90d16e00820c1cc43eadac60e60fb9f5cb92d093e97d7f2fadfd2c763434->leave($__internal_f3cd90d16e00820c1cc43eadac60e60fb9f5cb92d093e97d7f2fadfd2c763434_prof);

    }

    // line 5
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_40a1039d0cfb981b80a4219d53c25cb5941d8f265df31a45a1ead4f9ab6b6fb7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40a1039d0cfb981b80a4219d53c25cb5941d8f265df31a45a1ead4f9ab6b6fb7->enter($__internal_40a1039d0cfb981b80a4219d53c25cb5941d8f265df31a45a1ead4f9ab6b6fb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_36a4bf973f91d8528a8eec863f686a02b32c8c7b79ccb9ae247aacb5d73b53fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36a4bf973f91d8528a8eec863f686a02b32c8c7b79ccb9ae247aacb5d73b53fa->enter($__internal_36a4bf973f91d8528a8eec863f686a02b32c8c7b79ccb9ae247aacb5d73b53fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Listings"), "html", null, true);
        
        $__internal_36a4bf973f91d8528a8eec863f686a02b32c8c7b79ccb9ae247aacb5d73b53fa->leave($__internal_36a4bf973f91d8528a8eec863f686a02b32c8c7b79ccb9ae247aacb5d73b53fa_prof);

        
        $__internal_40a1039d0cfb981b80a4219d53c25cb5941d8f265df31a45a1ead4f9ab6b6fb7->leave($__internal_40a1039d0cfb981b80a4219d53c25cb5941d8f265df31a45a1ead4f9ab6b6fb7_prof);

    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        $__internal_c638bdfdb60f3e789d8ea750f86917fa6f208f5b21ccda2bb81f6307d84e61b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c638bdfdb60f3e789d8ea750f86917fa6f208f5b21ccda2bb81f6307d84e61b2->enter($__internal_c638bdfdb60f3e789d8ea750f86917fa6f208f5b21ccda2bb81f6307d84e61b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_81a610ea0999bb70035e5fc411c08e08c1ecfcba3ceeb1fe42bf34a982e979ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81a610ea0999bb70035e5fc411c08e08c1ecfcba3ceeb1fe42bf34a982e979ad->enter($__internal_81a610ea0999bb70035e5fc411c08e08c1ecfcba3ceeb1fe42bf34a982e979ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "    <div class=\"table-header clearfix\">
        <div class=\"table-header-count\">
            ";
        // line 10
        $context["count"] = twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["listings"]) || array_key_exists("listings", $context) ? $context["listings"] : (function () { throw new Twig_Error_Runtime('Variable "listings" does not exist.', 10, $this->getSourceContext()); })()), "getTotalItemCount", array());
        // line 11
        echo "            ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->transChoice("{0} <span>%count%</span> listings matching query|{1} <span>%count%</span> listing matching query|]1,Inf[<span>%count%</span> listings matching query", (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new Twig_Error_Runtime('Variable "count" does not exist.', 11, $this->getSourceContext()); })()), array("%count%" => (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new Twig_Error_Runtime('Variable "count" does not exist.', 11, $this->getSourceContext()); })())), "messages");
        // line 14
        echo "        </div><!-- /.table-header-count -->

        <div class=\"table-header-actions\">
            <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_listings_create");
        echo "\" class=\"btn btn-primary\">
                <i class=\"fa fa-plus\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Create Listing"), "html", null, true);
        echo "
            </a>
        </div><!-- /.table-header-actions -->
    </div><!-- /.table-header -->

    <div class=\"box\">
        <div class=\"box-inner\">
            <div class=\"box-title\">
                <h2>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Listings"), "html", null, true);
        echo "</h2>
            </div><!-- /.box-title -->

            ";
        // line 29
        if (twig_length_filter($this->env, (isset($context["listings"]) || array_key_exists("listings", $context) ? $context["listings"] : (function () { throw new Twig_Error_Runtime('Variable "listings" does not exist.', 29, $this->getSourceContext()); })()))) {
            // line 30
            echo "                <table class=\"table table-bordered\">
                    <thead>
                        <tr>
                            <th class=\"min-width center\">";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("ID"), "html", null, true);
            echo "</th>
                            <th>";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Title"), "html", null, true);
            echo "</th>
                            <th class=\"min-width center\">";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Category"), "html", null, true);
            echo "</th>
                            <th class=\"min-width price\">";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Price"), "html", null, true);
            echo "</th>
                            <th class=\"min-width center\">";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Published"), "html", null, true);
            echo "</th>
                            <th class=\"min-width center\">";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Verified"), "html", null, true);
            echo "</th>
                            <th class=\"min-width center\">";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Featured"), "html", null, true);
            echo "</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["listings"]) || array_key_exists("listings", $context) ? $context["listings"] : (function () { throw new Twig_Error_Runtime('Variable "listings" does not exist.', 45, $this->getSourceContext()); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["listing"]) {
                // line 46
                echo "                            <tr>
                                <td class=\"min-width center id\">#";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getId", array()), "html", null, true);
                echo "</td>
                                <td>
                                    ";
                // line 49
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "featuredName", array())) {
                    // line 50
                    echo "                                        <div class=\"avatar squared\"
                                             style=\"background-image: url('";
                    // line 51
                    echo twig_escape_filter($this->env, $this->env->getExtension('Vich\UploaderBundle\Twig\Extension\UploaderExtension')->asset($context["listing"], "featuredImage"), "html", null, true);
                    echo "');\">
                                        </div><!-- /.avatar -->
                                    ";
                }
                // line 54
                echo "
                                    <h2>
                                        ";
                // line 56
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getName", array()), "html", null, true);
                echo "
                                        ";
                // line 57
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getAddress", array())) {
                    // line 58
                    echo "                                            <span>";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getAddress", array()), "html", null, true);
                    echo "</span>
                                        ";
                }
                // line 60
                echo "                                    </h2>
                                </td>

                                <td class=\"min-width no-wrap center\">
                                    ";
                // line 64
                if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "categories", array()))) {
                    // line 65
                    echo "                                        ";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "categories", array()));
                    foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
                        // line 66
                        echo "                                            <span class=\"tag\">";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["category"], "getName", array()), "html", null, true);
                        echo "</span>
                                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 68
                    echo "                                    ";
                } else {
                    // line 69
                    echo "                                        -
                                    ";
                }
                // line 71
                echo "                                </td>

                                <td class=\"min-width price\">
                                    ";
                // line 74
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getPrice", array())) {
                    // line 75
                    echo "                                        ";
                    echo twig_escape_filter($this->env, twig_localized_currency_filter(twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getPrice", array()), "USD"), "html", null, true);
                    echo "
                                    ";
                } else {
                    // line 77
                    echo "                                        -
                                    ";
                }
                // line 79
                echo "                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        ";
                // line 83
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getIsPublished", array())) {
                    // line 84
                    echo "                                            <i class=\"fa fa-check\"></i>
                                        ";
                } else {
                    // line 86
                    echo "                                            <i class=\"fa fa-times\"></i>
                                        ";
                }
                // line 88
                echo "                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        ";
                // line 93
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getIsVerified", array())) {
                    // line 94
                    echo "                                            <i class=\"fa fa-check\"></i>
                                        ";
                } else {
                    // line 96
                    echo "                                            <i class=\"fa fa-times\"></i>
                                        ";
                }
                // line 98
                echo "                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        ";
                // line 103
                if (twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getIsFeatured", array())) {
                    // line 104
                    echo "                                            <i class=\"fa fa-check\"></i>
                                        ";
                } else {
                    // line 106
                    echo "                                            <i class=\"fa fa-times\"></i>
                                        ";
                }
                // line 108
                echo "                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width\">
                                    <div class=\"btn-group\" role=\"group\">
                                        <button id=\"btnGroupDrop1\" type=\"button\" class=\"btn btn-secondary dropdown-toggle\" data-toggle=\"dropdown\">
                                            ";
                // line 114
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Actions"), "html", null, true);
                echo "
                                        </button>

                                        <div class=\"dropdown-menu\">
                                            <a class=\"dropdown-item\" href=\"";
                // line 118
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_listings_update", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getId", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Update"), "html", null, true);
                echo "</a>
                                            <a class=\"dropdown-item\" href=\"";
                // line 119
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_listings_delete", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["listing"], "getId", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Delete"), "html", null, true);
                echo "</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['listing'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 125
            echo "                    </tbody>
                </table>
            ";
        } else {
            // line 128
            echo "                <p class=\"mb0\">
                    ";
            // line 129
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("No listings found."), "html", null, true);
            echo "
                </p>
            ";
        }
        // line 132
        echo "        </div><!-- /.box-inner -->
    </div><!-- /.box -->

    <div class=\"navigation text-center\">
        ";
        // line 136
        echo $this->env->getExtension('Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension')->render($this->env, (isset($context["listings"]) || array_key_exists("listings", $context) ? $context["listings"] : (function () { throw new Twig_Error_Runtime('Variable "listings" does not exist.', 136, $this->getSourceContext()); })()));
        echo "
    </div>
";
        
        $__internal_81a610ea0999bb70035e5fc411c08e08c1ecfcba3ceeb1fe42bf34a982e979ad->leave($__internal_81a610ea0999bb70035e5fc411c08e08c1ecfcba3ceeb1fe42bf34a982e979ad_prof);

        
        $__internal_c638bdfdb60f3e789d8ea750f86917fa6f208f5b21ccda2bb81f6307d84e61b2->leave($__internal_c638bdfdb60f3e789d8ea750f86917fa6f208f5b21ccda2bb81f6307d84e61b2_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle::Listings/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 136,  346 => 132,  340 => 129,  337 => 128,  332 => 125,  318 => 119,  312 => 118,  305 => 114,  297 => 108,  293 => 106,  289 => 104,  287 => 103,  280 => 98,  276 => 96,  272 => 94,  270 => 93,  263 => 88,  259 => 86,  255 => 84,  253 => 83,  247 => 79,  243 => 77,  237 => 75,  235 => 74,  230 => 71,  226 => 69,  223 => 68,  214 => 66,  209 => 65,  207 => 64,  201 => 60,  195 => 58,  193 => 57,  189 => 56,  185 => 54,  179 => 51,  176 => 50,  174 => 49,  169 => 47,  166 => 46,  162 => 45,  153 => 39,  149 => 38,  145 => 37,  141 => 36,  137 => 35,  133 => 34,  129 => 33,  124 => 30,  122 => 29,  116 => 26,  105 => 18,  101 => 17,  96 => 14,  93 => 11,  91 => 10,  87 => 8,  78 => 7,  60 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AdminBundle::base.html.twig' %}

{% block title %}{{ 'Listings'|trans }}{% endblock %}

{% block page_title %}{{ 'Listings'|trans }}{% endblock %}

{% block content %}
    <div class=\"table-header clearfix\">
        <div class=\"table-header-count\">
            {% set count = listings.getTotalItemCount %}
            {% transchoice count %}
            {0} <span>%count%</span> listings matching query|{1} <span>%count%</span> listing matching query|]1,Inf[<span>%count%</span> listings matching query
            {% endtranschoice %}
        </div><!-- /.table-header-count -->

        <div class=\"table-header-actions\">
            <a href=\"{{ path('admin_listings_create') }}\" class=\"btn btn-primary\">
                <i class=\"fa fa-plus\"></i> {{ 'Create Listing'|trans }}
            </a>
        </div><!-- /.table-header-actions -->
    </div><!-- /.table-header -->

    <div class=\"box\">
        <div class=\"box-inner\">
            <div class=\"box-title\">
                <h2>{{ 'Listings'|trans }}</h2>
            </div><!-- /.box-title -->

            {% if listings|length %}
                <table class=\"table table-bordered\">
                    <thead>
                        <tr>
                            <th class=\"min-width center\">{{ 'ID'|trans }}</th>
                            <th>{{ 'Title'|trans }}</th>
                            <th class=\"min-width center\">{{ 'Category'|trans }}</th>
                            <th class=\"min-width price\">{{ 'Price'|trans }}</th>
                            <th class=\"min-width center\">{{ 'Published'|trans }}</th>
                            <th class=\"min-width center\">{{ 'Verified'|trans }}</th>
                            <th class=\"min-width center\">{{ 'Featured'|trans }}</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        {% for listing in listings %}
                            <tr>
                                <td class=\"min-width center id\">#{{ listing.getId }}</td>
                                <td>
                                    {% if listing.featuredName %}
                                        <div class=\"avatar squared\"
                                             style=\"background-image: url('{{ vich_uploader_asset(listing, 'featuredImage') }}');\">
                                        </div><!-- /.avatar -->
                                    {% endif %}

                                    <h2>
                                        {{ listing.getName }}
                                        {% if listing.getAddress %}
                                            <span>{{ listing.getAddress }}</span>
                                        {% endif %}
                                    </h2>
                                </td>

                                <td class=\"min-width no-wrap center\">
                                    {% if listing.categories|length %}
                                        {% for category in listing.categories %}
                                            <span class=\"tag\">{{ category.getName }}</span>
                                        {% endfor %}
                                    {% else %}
                                        -
                                    {% endif %}
                                </td>

                                <td class=\"min-width price\">
                                    {% if listing.getPrice %}
                                        {{ listing.getPrice|localizedcurrency(\"USD\") }}
                                    {% else %}
                                        -
                                    {% endif %}
                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        {% if listing.getIsPublished %}
                                            <i class=\"fa fa-check\"></i>
                                        {% else %}
                                            <i class=\"fa fa-times\"></i>
                                        {% endif %}
                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        {% if listing.getIsVerified %}
                                            <i class=\"fa fa-check\"></i>
                                        {% else %}
                                            <i class=\"fa fa-times\"></i>
                                        {% endif %}
                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width center\">
                                    <div class=\"status\">
                                        {% if listing.getIsFeatured %}
                                            <i class=\"fa fa-check\"></i>
                                        {% else %}
                                            <i class=\"fa fa-times\"></i>
                                        {% endif %}
                                    </div><!-- /.status -->
                                </td>

                                <td class=\"min-width\">
                                    <div class=\"btn-group\" role=\"group\">
                                        <button id=\"btnGroupDrop1\" type=\"button\" class=\"btn btn-secondary dropdown-toggle\" data-toggle=\"dropdown\">
                                            {{ 'Actions'|trans }}
                                        </button>

                                        <div class=\"dropdown-menu\">
                                            <a class=\"dropdown-item\" href=\"{{ path('admin_listings_update', {'id': listing.getId}) }}\">{{ 'Update'|trans }}</a>
                                            <a class=\"dropdown-item\" href=\"{{ path('admin_listings_delete', {'id': listing.getId}) }}\">{{ 'Delete'|trans }}</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
            {% else %}
                <p class=\"mb0\">
                    {{ 'No listings found.'|trans }}
                </p>
            {% endif %}
        </div><!-- /.box-inner -->
    </div><!-- /.box -->

    <div class=\"navigation text-center\">
        {{ knp_pagination_render(listings) }}
    </div>
{% endblock %}", "AdminBundle::Listings/list.html.twig", "/Users/lukas/Sites/explorer_html/backend/src/Explorer/AdminBundle/Resources/views/Listings/list.html.twig");
    }
}
