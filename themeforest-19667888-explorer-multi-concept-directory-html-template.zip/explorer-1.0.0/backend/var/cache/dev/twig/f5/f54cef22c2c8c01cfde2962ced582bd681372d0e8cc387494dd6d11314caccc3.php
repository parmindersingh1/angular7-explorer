<?php

/* AdminBundle::Helpers/messages.html.twig */
class __TwigTemplate_a276b39f177553e0307cb5bda622156d34e0291b4a2b7d679650312c3bce7d7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19832c2e9d9b7cce136ce8c13c2f1d4d4bec837d198001204fc5b058d84b5d14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19832c2e9d9b7cce136ce8c13c2f1d4d4bec837d198001204fc5b058d84b5d14->enter($__internal_19832c2e9d9b7cce136ce8c13c2f1d4d4bec837d198001204fc5b058d84b5d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::Helpers/messages.html.twig"));

        $__internal_a0ab748908f1d0c0500fa37c4404718d5661f7487e75259a61819e3cf2240e9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0ab748908f1d0c0500fa37c4404718d5661f7487e75259a61819e3cf2240e9a->enter($__internal_a0ab748908f1d0c0500fa37c4404718d5661f7487e75259a61819e3cf2240e9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::Helpers/messages.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 1, $this->getSourceContext()); })()), "session", array()), "flashbag", array()), "all", array()));
        foreach ($context['_seq'] as $context["type"] => $context["flashes"]) {
            // line 2
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["flashes"]);
            foreach ($context['_seq'] as $context["_key"] => $context["flash"]) {
                // line 3
                echo "        <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">
            ";
                // line 4
                echo twig_escape_filter($this->env, $context["flash"], "html", null, true);
                echo "
        </div>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['flashes'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_19832c2e9d9b7cce136ce8c13c2f1d4d4bec837d198001204fc5b058d84b5d14->leave($__internal_19832c2e9d9b7cce136ce8c13c2f1d4d4bec837d198001204fc5b058d84b5d14_prof);

        
        $__internal_a0ab748908f1d0c0500fa37c4404718d5661f7487e75259a61819e3cf2240e9a->leave($__internal_a0ab748908f1d0c0500fa37c4404718d5661f7487e75259a61819e3cf2240e9a_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle::Helpers/messages.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 4,  34 => 3,  29 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% for type, flashes in app.session.flashbag.all %}
    {% for flash in flashes %}
        <div class=\"alert alert-{{ type }}\">
            {{ flash }}
        </div>
    {% endfor %}
{% endfor %}", "AdminBundle::Helpers/messages.html.twig", "/Users/lukas/Sites/explorer_html/backend/src/Explorer/AdminBundle/Resources/views/Helpers/messages.html.twig");
    }
}
