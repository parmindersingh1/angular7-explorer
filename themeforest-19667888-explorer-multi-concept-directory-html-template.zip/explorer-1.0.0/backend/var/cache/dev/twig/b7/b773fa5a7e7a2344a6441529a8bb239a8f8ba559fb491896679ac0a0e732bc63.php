<?php

/* AdminBundle::base.html.twig */
class __TwigTemplate_d364edadbc50f0aadf5bb0e3530b6bfafc285d2237d652b07d65626465f2bcd4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body_class' => array($this, 'block_body_class'),
            'page_title' => array($this, 'block_page_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4a4e8f7a97549fc53a5133e511c8da84fcb56803113cdbda3d8ebbd1fb9c997 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4a4e8f7a97549fc53a5133e511c8da84fcb56803113cdbda3d8ebbd1fb9c997->enter($__internal_f4a4e8f7a97549fc53a5133e511c8da84fcb56803113cdbda3d8ebbd1fb9c997_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::base.html.twig"));

        $__internal_5c7523e61b1ca215c4fec5a38b887819bd5f63e30dab314dccc17f55e6800421 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c7523e61b1ca215c4fec5a38b887819bd5f63e30dab314dccc17f55e6800421->enter($__internal_5c7523e61b1ca215c4fec5a38b887819bd5f63e30dab314dccc17f55e6800421_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1\">

    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo " | ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Explorer Admin"), "html", null, true);
        echo "</title>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.png"), "html", null, true);
        echo "\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato:300,400,700\" rel=\"stylesheet\">

    ";
        // line 12
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "243a495_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_243a495_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/243a495_font-awesome_1.css");
            // line 15
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 15, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/css\">
    ";
            // asset "243a495_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_243a495_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/243a495_explorer_2.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 15, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/css\">
    ";
        } else {
            // asset "243a495"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_243a495") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/243a495.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 15, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/css\">
    ";
        }
        unset($context["asset_url"]);
        // line 17
        echo "</head>

<body class=\"";
        // line 19
        $this->displayBlock('body_class', $context, $blocks);
        echo "\">

<div class=\"admin-wrapper\">
    <div class=\"admin-main\">
        <div class=\"admin-header\">
            <div class=\"container\">
                <div class=\"primary-nav-wrapper\">
                    <ul class=\"nav\">
                        <li class=\"nav-item\">
                            <a href=\"";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_listings_list");
        echo "\" class=\"nav-link \">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Listings"), "html", null, true);
        echo "</a>
                        </li>

                        <li class=\"nav-item\">
                            <a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_categories_list");
        echo "\" class=\"nav-link \">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Categories"), "html", null, true);
        echo "</a>
                        </li>
                    </ul>
                </div><!-- /.primary-nav-wrapper -->
            </div><!-- /.container -->
        </div>

        <div class=\"admin-page-title\">
            <div class=\"container\">
                <a href=\"";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_listings_list");
        echo "\" class=\"admin-page-title-back\">
                    <i class=\"fa fa-long-arrow-left\"></i>
                </a>

                <h1>";
        // line 45
        $this->displayBlock('page_title', $context, $blocks);
        echo "</h1>
            </div><!-- /.container-fluid -->
        </div>

        <div class=\"admin-content\">
            <div class=\"container\">
                ";
        // line 51
        echo twig_include($this->env, $context, "AdminBundle::Helpers/messages.html.twig");
        echo "

                ";
        // line 53
        $this->displayBlock('content', $context, $blocks);
        // line 54
        echo "            </div><!-- /.container-fluid -->
        </div><!-- /.admin-content -->
    </div><!-- /.admin-main -->
</div><!-- /.admin-wrapper -->

";
        // line 59
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "87a8956_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_87a8956_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/87a8956_jquery_1.js");
            // line 65
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 65, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/javascript\"></script>
";
            // asset "87a8956_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_87a8956_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/87a8956_tether_2.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 65, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/javascript\"></script>
";
            // asset "87a8956_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_87a8956_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/87a8956_bootstrap_3.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 65, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/javascript\"></script>
";
            // asset "87a8956_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_87a8956_3") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/87a8956_admin_4.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 65, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/javascript\"></script>
";
        } else {
            // asset "87a8956"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_87a8956") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/87a8956.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) || array_key_exists("asset_url", $context) ? $context["asset_url"] : (function () { throw new Twig_Error_Runtime('Variable "asset_url" does not exist.', 65, $this->getSourceContext()); })()), "html", null, true);
            echo "\" type=\"text/javascript\"></script>
";
        }
        unset($context["asset_url"]);
        // line 67
        echo "

</body>
</html>";
        
        $__internal_f4a4e8f7a97549fc53a5133e511c8da84fcb56803113cdbda3d8ebbd1fb9c997->leave($__internal_f4a4e8f7a97549fc53a5133e511c8da84fcb56803113cdbda3d8ebbd1fb9c997_prof);

        
        $__internal_5c7523e61b1ca215c4fec5a38b887819bd5f63e30dab314dccc17f55e6800421->leave($__internal_5c7523e61b1ca215c4fec5a38b887819bd5f63e30dab314dccc17f55e6800421_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_7f97a19fef6c56cb7745a85fbf90bf0d143826c3b80d43ebc0a127832d73f72b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f97a19fef6c56cb7745a85fbf90bf0d143826c3b80d43ebc0a127832d73f72b->enter($__internal_7f97a19fef6c56cb7745a85fbf90bf0d143826c3b80d43ebc0a127832d73f72b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_8ae3d54e2c389e099e08204288639230a5d535a4cd50b34b1b97555dc33965eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ae3d54e2c389e099e08204288639230a5d535a4cd50b34b1b97555dc33965eb->enter($__internal_8ae3d54e2c389e099e08204288639230a5d535a4cd50b34b1b97555dc33965eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_8ae3d54e2c389e099e08204288639230a5d535a4cd50b34b1b97555dc33965eb->leave($__internal_8ae3d54e2c389e099e08204288639230a5d535a4cd50b34b1b97555dc33965eb_prof);

        
        $__internal_7f97a19fef6c56cb7745a85fbf90bf0d143826c3b80d43ebc0a127832d73f72b->leave($__internal_7f97a19fef6c56cb7745a85fbf90bf0d143826c3b80d43ebc0a127832d73f72b_prof);

    }

    // line 19
    public function block_body_class($context, array $blocks = array())
    {
        $__internal_29b4b3e4b52f7c15d9ea6c203a0af85144fe4a44c2c2c67a024fae35f2f5c780 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29b4b3e4b52f7c15d9ea6c203a0af85144fe4a44c2c2c67a024fae35f2f5c780->enter($__internal_29b4b3e4b52f7c15d9ea6c203a0af85144fe4a44c2c2c67a024fae35f2f5c780_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_class"));

        $__internal_b618d151f0dd1656069c38b7ee3ec20e351b92e47f1e58ebef91303957ff4cf2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b618d151f0dd1656069c38b7ee3ec20e351b92e47f1e58ebef91303957ff4cf2->enter($__internal_b618d151f0dd1656069c38b7ee3ec20e351b92e47f1e58ebef91303957ff4cf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_class"));

        
        $__internal_b618d151f0dd1656069c38b7ee3ec20e351b92e47f1e58ebef91303957ff4cf2->leave($__internal_b618d151f0dd1656069c38b7ee3ec20e351b92e47f1e58ebef91303957ff4cf2_prof);

        
        $__internal_29b4b3e4b52f7c15d9ea6c203a0af85144fe4a44c2c2c67a024fae35f2f5c780->leave($__internal_29b4b3e4b52f7c15d9ea6c203a0af85144fe4a44c2c2c67a024fae35f2f5c780_prof);

    }

    // line 45
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_3b1de64208e2b3e372d1c9fa0863ac2f4c9cd66d09215ede921989bbc139ee7e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b1de64208e2b3e372d1c9fa0863ac2f4c9cd66d09215ede921989bbc139ee7e->enter($__internal_3b1de64208e2b3e372d1c9fa0863ac2f4c9cd66d09215ede921989bbc139ee7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_80c7131c86ba0657486d79d50d25b3a65a81a5bb0ce0a7a4e0871b82f54d8ee2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80c7131c86ba0657486d79d50d25b3a65a81a5bb0ce0a7a4e0871b82f54d8ee2->enter($__internal_80c7131c86ba0657486d79d50d25b3a65a81a5bb0ce0a7a4e0871b82f54d8ee2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        
        $__internal_80c7131c86ba0657486d79d50d25b3a65a81a5bb0ce0a7a4e0871b82f54d8ee2->leave($__internal_80c7131c86ba0657486d79d50d25b3a65a81a5bb0ce0a7a4e0871b82f54d8ee2_prof);

        
        $__internal_3b1de64208e2b3e372d1c9fa0863ac2f4c9cd66d09215ede921989bbc139ee7e->leave($__internal_3b1de64208e2b3e372d1c9fa0863ac2f4c9cd66d09215ede921989bbc139ee7e_prof);

    }

    // line 53
    public function block_content($context, array $blocks = array())
    {
        $__internal_588369e5e3b8e404fee0752d053abc4d7480e232df3641426b38e9c423bb820b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_588369e5e3b8e404fee0752d053abc4d7480e232df3641426b38e9c423bb820b->enter($__internal_588369e5e3b8e404fee0752d053abc4d7480e232df3641426b38e9c423bb820b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_9507af4799b6f1cdb91381900acb91a1579e0568b2bc30858ed95996d602430a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9507af4799b6f1cdb91381900acb91a1579e0568b2bc30858ed95996d602430a->enter($__internal_9507af4799b6f1cdb91381900acb91a1579e0568b2bc30858ed95996d602430a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_9507af4799b6f1cdb91381900acb91a1579e0568b2bc30858ed95996d602430a->leave($__internal_9507af4799b6f1cdb91381900acb91a1579e0568b2bc30858ed95996d602430a_prof);

        
        $__internal_588369e5e3b8e404fee0752d053abc4d7480e232df3641426b38e9c423bb820b->leave($__internal_588369e5e3b8e404fee0752d053abc4d7480e232df3641426b38e9c423bb820b_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  243 => 53,  226 => 45,  209 => 19,  192 => 8,  179 => 67,  147 => 65,  143 => 59,  136 => 54,  134 => 53,  129 => 51,  120 => 45,  113 => 41,  99 => 32,  90 => 28,  78 => 19,  74 => 17,  54 => 15,  50 => 12,  44 => 9,  38 => 8,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1\">

    <title>{% block title %}{% endblock %} | {{ 'Explorer Admin'|trans }}</title>
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.png') }}\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato:300,400,700\" rel=\"stylesheet\">

    {% stylesheets
    '@AdminBundle/Resources/public/fonts/font-awesome/css/font-awesome.css' filter='cssrewrite'
    '@AdminBundle/Resources/public/css/explorer.css' filter='cssrewrite' %}
    <link rel=\"stylesheet\" href=\"{{ asset_url }}\" type=\"text/css\">
    {% endstylesheets %}
</head>

<body class=\"{% block body_class %}{% endblock %}\">

<div class=\"admin-wrapper\">
    <div class=\"admin-main\">
        <div class=\"admin-header\">
            <div class=\"container\">
                <div class=\"primary-nav-wrapper\">
                    <ul class=\"nav\">
                        <li class=\"nav-item\">
                            <a href=\"{{ path('admin_listings_list') }}\" class=\"nav-link \">{{ 'Listings'|trans }}</a>
                        </li>

                        <li class=\"nav-item\">
                            <a href=\"{{ path('admin_categories_list') }}\" class=\"nav-link \">{{ 'Categories'|trans }}</a>
                        </li>
                    </ul>
                </div><!-- /.primary-nav-wrapper -->
            </div><!-- /.container -->
        </div>

        <div class=\"admin-page-title\">
            <div class=\"container\">
                <a href=\"{{ path('admin_listings_list') }}\" class=\"admin-page-title-back\">
                    <i class=\"fa fa-long-arrow-left\"></i>
                </a>

                <h1>{% block page_title %}{% endblock %}</h1>
            </div><!-- /.container-fluid -->
        </div>

        <div class=\"admin-content\">
            <div class=\"container\">
                {{ include('AdminBundle::Helpers/messages.html.twig') }}

                {% block content %}{% endblock %}
            </div><!-- /.container-fluid -->
        </div><!-- /.admin-content -->
    </div><!-- /.admin-main -->
</div><!-- /.admin-wrapper -->

{% javascripts
'@AdminBundle/Resources/public/js/jquery.js'
'@AdminBundle/Resources/public/js/tether.js'
'@AdminBundle/Resources/public/js/bootstrap.js'
'@AdminBundle/Resources/public/js/admin.js'
%}
    <script src=\"{{ asset_url }}\" type=\"text/javascript\"></script>
{% endjavascripts %}


</body>
</html>", "AdminBundle::base.html.twig", "/Users/lukas/Sites/explorer_html/backend/src/Explorer/AdminBundle/Resources/views/base.html.twig");
    }
}
