<?php

// AdminBundle:Listings:list.html.twig
return array (
  '243a495' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/fonts/font-awesome/css/font-awesome.css',
      1 => '@AdminBundle/Resources/public/css/explorer.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
      1 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/243a495.css',
      'name' => '243a495',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '87a8956' => 
  array (
    0 => 
    array (
      0 => '@AdminBundle/Resources/public/js/jquery.js',
      1 => '@AdminBundle/Resources/public/js/tether.js',
      2 => '@AdminBundle/Resources/public/js/bootstrap.js',
      3 => '@AdminBundle/Resources/public/js/admin.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/87a8956.js',
      'name' => '87a8956',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
